<?= view('estudiantes') ?>
